from flask import Flask, request, jsonify
import logging
from services.kiosk_services import kiosk_response_queue # Import the queue

logger = logging.getLogger(__name__)

def register_kiosk_routes(app):
    """
    Registers the Flask route for handling kiosk responses.  This function should
    be called by the main Flask application.

    Args:
        app (Flask): The Flask application instance.
    """
    @app.route('/kiosk-barrier-response', methods=['POST'])  # New endpoint for Kiosk
    def receive_kiosk_response():
        """
        Receives a POST request from the kiosk after the print button is clicked.
        This request should contain the license plate of the vehicle.
        """
        data = request.get_json()
        license_plate = data.get('license_plate')

        if not license_plate:
            return jsonify({"status": "error", "message": "license_plate missing from kiosk response"}), 400

        kiosk_response_queue.put(data)  # Put the data in the queue
        print(f"[KIOSK RESPONSE QUEUE SIZE]: {kiosk_response_queue.qsize()}")
        return jsonify({"status": "received", "message": "Kiosk response received"}), 200

    @app.route('/receive_data', methods=['GET', 'POST'])
    def receive_data():
        """
        This route receives data (license plate, entry time, barcode) from the
        handle_anpr_entry function.  It handles both GET and POST requests.
        """
        global last_received_data  # Access the global variable

        if request.method == 'POST':
            data = request.get_json()
            if data:
                last_received_data = data # store the data
                license_plate = data.get('license_plate')
                entry_time = data.get('entry_time')
                barcode_image = data.get('barcode_image')
                printable_slip = data.get('printable_slip')

                if not license_plate or not entry_time or not barcode_image or not printable_slip:
                    logger.error("Missing data in /receive_data POST request")
                    return jsonify({"status": "error", "message": "Missing data in POST request"}), 400

                logger.info(f"Received data at /receive_data (POST): {data}")
                print(f"[INFO] Received data at /receive_data (POST): {data}")
                # Process the data as needed
                return jsonify({"status": "success", "message": "Data received successfully (POST)"}), 200
            else:
                logger.error("Empty payload in /receive_data POST request")
                return jsonify({"status": "error", "message": "Empty payload in POST request"}), 400

        elif request.method == 'GET':
            logger.info(f"Received data at /receive_data (GET)")
            print(f"[INFO] Received data at /receive_data (GET)")
            #  The Kiosk is likely expecting some kind of response, even to a GET.
            if last_received_data:
                return jsonify({"status": "success", "message": "Last data sent", "data": last_received_data}), 200
            else:
                return jsonify({"status": "success", "message": "No data has been sent yet", "data": {}}), 200
        else:
            return jsonify({"status": "error", "message": "Method not allowed"}), 405