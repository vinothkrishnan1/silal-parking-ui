from flask import Flask
from models import db
from routes.auth_routes import auth_bp
from flask_cors import CORS
import os
from services.create_admin import create_initial_admin  # Your initial admin setup
from services.camera_listener import register_camera_routes, start_camera_listeners
from routes.kiosk_routes import register_kiosk_routes
from routes.on_exit_routes import register_on_exit_routes
# from routes.kiosk_routes import register_kiosk_routes_from_module # Import
# from routes.vehicle_routes import vehicle_bp

def create_app():
    app = Flask(__name__)

    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config.from_prefixed_env()

    CORS(app)

    db_path = r'C:\ProgramData\MySQL\MySQL Server 9.3\Data\pro_parking'

    with app.app_context():
        if not os.path.exists(db_path):
            db.create_all()
            print("Database created.")
        else:
            print("Using existing database.", db_path)

    db.init_app(app)

    app.register_blueprint(auth_bp, url_prefix='/auth')
    # app.register_blueprint(vehicle_bp, url_prefix='/vehicle')
    
    #creating the admin user
    create_initial_admin(app)

    # Register camera listener routes
    register_camera_routes(app)
    
    # Register kiosk routes
    register_kiosk_routes(app) # Register kiosk routes
    
    # Start background ANPR entry/exit listeners after the app is created
    start_camera_listeners(app)
    
    # register_kiosk_routes_from_module(app)  # Register kiosk routes from the new module
    register_on_exit_routes(app)
    


    @app.errorhandler(404)
    def not_found_error(error):
        return {"message": "Resource not found"}, 404

    @app.errorhandler(500)
    def internal_error(error):
        return {"message": "Internal server error"}, 500

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', debug=True)