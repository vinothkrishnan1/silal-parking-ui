import threading
import time
from flask import request, jsonify, current_app
import logging
from models import db, Vehicle
import requests
import sys
import base64
from io import BytesIO
from barcode import Code128
from barcode.writer import ImageWriter
import json
from requests.auth import HTTPDigestAuth  # Import HTTPDigestAuth
import queue

logger = logging.getLogger(__name__)
kiosk_response_queue = queue.Queue()


# KIOSK_ENDPOINT = "http://<kiosk_ip>:<port>/print_barcode"
KIOSK_BARRIER_ENDPOINT = "http://<hikvision-ip>/ISAPI/AccessControl/remoteControl/door/1"  # Hikvision ISAPI endpoint
KIOSK_WEBSITE_ENDPOINT = "http://localhost:5000/receive_data"
HIKVISION_USERNAME = "admin"  #  Move to a config file
HIKVISION_PASSWORD = "password"  # Move to a config file



def generate_barcode(data):
    """
    Generates a barcode from the given data.

    Args:
        data (str): The data to encode in the barcode.

    Returns:
        str: base64 encoded string or None on error.
    """
    try:
        barcode_data = f"{data}"
        barcode_img_io = BytesIO()
        barcode = Code128(barcode_data, writer=ImageWriter())
        barcode.write(barcode_img_io)
        barcode_img_io.seek(0)
        barcode_base64 = base64.b64encode(barcode_img_io.read()).decode('utf-8')
        return barcode_base64
    except Exception as e:
        logger.error(f"Error generating barcode: {e}")
        print(f"[ERROR] Error generating barcode: {e}", file=sys.stderr)
        return None


def send_data_to_website(payload):
    """
    Sends the barcode and date to a separate website endpoint.

    Args:
        payload (dict): The data to send (barcode and date).
    """
    try:
        response = requests.post(KIOSK_WEBSITE_ENDPOINT, json=payload)
        response.raise_for_status()
        logger.info(f"Successfully sent data to website: {payload}")
        return jsonify("OK"), 200
    except requests.RequestException as e:
        logger.error(f"Failed to send data to website: {e}")
        print(f"[ERROR] Failed to send data to website: {e}", file=sys.stderr)
        return jsonify(e), 500



def open_barrier_hikvision():
    """
    Sends a request to the Hikvision controller to open the boom barrier using ISAPI.
    """
    headers = {
        "Content-Type": "application/xml"
    }
    xml_payload = """
        <RemoteControlDoor>
            <doorNo>1</doorNo>
            <cmd>open</cmd>
        </RemoteControlDoor>
    """
    try:
        response = requests.post(
            KIOSK_BARRIER_ENDPOINT,
            data=xml_payload.strip(),
            headers=headers,
            auth=HTTPDigestAuth(HIKVISION_USERNAME, HIKVISION_PASSWORD),
            timeout=5
        )
        response.raise_for_status()  # Raise for status to catch HTTP errors
        logger.info("Boom barrier opened successfully (Hikvision ISAPI).")
        print("Boom barrier opened successfully. (Hikvision ISAPI)")
        return {"message": "Barrier opened"}  # Return a success message
    except requests.RequestException as e:
        logger.error(f"Exception occurred while opening barrier (Hikvision ISAPI): {e}")
        print(f"[ERROR] Exception occurred while opening barrier (Hikvision ISAPI): {e}")
        return {"error": str(e)}  # Return the error



# def process_kiosk_response_data(app):
#     """
#     Processes responses from the kiosk machine (e.g., after print button is pressed).
#     This function should be run in a background thread.
#     """
#     while True:
#         if not kiosk_response_queue.empty():
#             data = kiosk_response_queue.get()
#             with app.app_context():
#                 license_plate = data.get('license_plate')
#                 print(f"[DEBUG] Processing kiosk response for: {license_plate}")
#                 try:
#                     vehicle = Vehicle.query.filter_by(license_plate=license_plate, status='in').first()
#                     if vehicle:
#                         # Generate barcode
#                         barcode_data = f"{license_plate}, {vehicle.entry_time.strftime('%Y-%m-%d %H:%M:%S')}"
#                         barcode_image_base64 = generate_barcode(barcode_data)
#                         if barcode_image_base64:
#                             # Send barcode and data to website
#                             website_payload = {
#                                 "license_plate": license_plate,
#                                 "entry_time": vehicle.entry_time.strftime('%Y-%m-%d %H:%M:%S'),
#                                 "barcode_image": barcode_image_base64,
#                             }
#                             send_data_to_website(website_payload)
#                         #  Open the barrier using the Hikvision ISAPI
#                         barrier_result = open_barrier_hikvision()
#                         if barrier_result and "error" not in barrier_result:
#                             vehicle.status = 'out'  # Update status AFTER successful barrier opening
#                             db.session.commit()
#                             logger.info(
#                                 f"Vehicle status updated to 'out' and barrier opened for license plate: {license_plate}")
#                             print(
#                                 f"[INFO] Vehicle status updated to 'out' and barrier opened for license plate: {license_plate}")
#                         else:
#                             logger.error(f"Failed to open barrier for license plate: {license_plate}.  Vehicle status not updated.")
#                             print(f"[ERROR] Failed to open barrier for license plate: {license_plate}. Vehicle status not updated.")
#                             #  Consider *not* updating the vehicle status here, or perhaps setting it to a different value
#                             #  (e.g., 'pending_exit', 'exit_error') to indicate that the barrier didn't open.
#                             #  For now, I'm leaving the vehicle.status as is.
#                     else:
#                         logger.error(f"Vehicle with license plate {license_plate} not found or not 'in'")
#                         print(f"[ERROR] Vehicle with license plate {license_plate} not found or not 'in'",
#                               file=sys.stderr)
#                 except Exception as e:
#                     logger.error(f"Error processing kiosk response: {e}")
#                     print(f"[ERROR] Error processing kiosk response: {e}", file=sys.stderr)
#         time.sleep(1)


