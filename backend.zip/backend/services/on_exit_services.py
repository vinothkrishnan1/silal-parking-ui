from flask import request, jsonify
import logging
from models import Vehicle, db
from sqlalchemy import desc
from sqlalchemy import func

logger = logging.getLogger(__name__)

last_exit_post_data = {}


EXIT_PING_ENDPOINT = "http://localhost:5000/exit_ping_on_exit"  # Replace with env/config if needed

def update_payment_status():
    """
    Receives payment status updates from the on_exit desktop website.
    """
    data = request.get_json()
    license_plate = data.get('license_plate')
    payment_status = data.get('payment_status')
    payment_mode = data.get('payment_mode')

    if not license_plate or not payment_status:
        return jsonify({"status": "error", "message": "Missing license_plate or payment_status"}), 400

    try:
        vehicle = Vehicle.query.filter_by(license_plate=license_plate).first()
        if vehicle:
            vehicle.payment_status = payment_status
            vehicle.payment_mode = payment_mode
            db.session.commit()
            logger.info(f"Payment status for {license_plate} updated to {payment_status}")
            return jsonify({"status": "success", "message": "Payment status updated"}), 200
        else:
            logger.error(f"Vehicle with license plate {license_plate} not found")
            return jsonify({"status": "error", "message": f"Vehicle with license plate {license_plate} not found"}), 404
    except Exception as e:
        logger.error(f"Error updating payment status: {e}")
        return jsonify({"status": "error", "message": f"Error updating payment status: {e}"}), 500

def exit_ping_on_exit():
    """
    Handles GET and POST pings from the exit system.
    POST stores the vehicle info and returns it.
    GET returns the same data that was posted last time.
    """
    global last_exit_post_data

    if request.method == 'POST':
        data = request.get_json()
        license_plate = data.get('license_plate')

        if not license_plate:
            return jsonify({"status": "error", "message": "Missing license_plate in POST data"}), 400

        try:
            vehicle = Vehicle.query.filter(
                func.lower(Vehicle.license_plate) == func.lower(license_plate)
            ).order_by(desc(Vehicle.entry_time)).first()

            if vehicle:
                last_exit_post_data = {  # Store for GET
                    "license_plate": vehicle.license_plate,
                    "entry_time": vehicle.entry_time.isoformat() if vehicle.entry_time else None,
                    "exit_time": vehicle.exit_time.isoformat() if vehicle.exit_time else None,
                    "duration": round(vehicle.duration.total_seconds() / 60, 2) if vehicle.duration else None,
                    "payable_amount": round(vehicle.payable_amount, 2) if vehicle.payable_amount else None
                }

                return jsonify({
                    "status": "success",
                    "message": "Vehicle data retrieved (POST)",
                    **last_exit_post_data
                }), 200
            else:
                return jsonify({"status": "success", "message": "No vehicle entries found"}), 200

        except Exception as e:
            logger.error(f"Error retrieving vehicle data: {e}")
            return jsonify({"status": "error", "message": f"Error retrieving vehicle data: {e}"}), 500

    elif request.method == 'GET':
        logger.info("Exit system pinged (GET) for last known vehicle data.")
        if last_exit_post_data:
            return jsonify({
                "status": "success",
                "message": "Last vehicle data retrieved (GET)",
                **last_exit_post_data
            }), 200
        else:
            return jsonify({"status": "success", "message": "No data has been sent yet", "data": {}}), 200

    return jsonify({"status": "error", "message": "Method not allowed"}), 405