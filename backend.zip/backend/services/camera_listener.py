import threading
import time
from flask import request, jsonify, current_app
from services.vehicle_services import handle_anpr_entry, handle_anpr_exit, is_duplicate_entry
import queue  # Use a thread-safe queue for data storage
import logging

# Enable Flask logging for background threads
logger = logging.getLogger(__name__)

# Queue to store entry and exit data
entry_queue = queue.Queue()
exit_queue = queue.Queue()

def register_camera_routes(app):
    @app.route('/entry-anpr', methods=['POST'])
    def receive_entry_data():
        data = request.get_json()
        license_plate = data.get('license_plate')

        if not license_plate:
            return jsonify({"status": "error", "message": "license_plate missing"}), 400

        entry_queue.put(data)  # Put data into the queue for processing

        print(f"[ENTRY QUEUE SIZE]: {entry_queue.qsize()}")

        response = {
            "status": "received",
            "camera": "entry",
            "data": data
        }
        return jsonify(response), 200

    @app.route('/exit-anpr', methods=['POST'])
    def receive_exit_data():
        data = request.get_json()
        license_plate = data.get('license_plate')

        if not license_plate:
            return jsonify({"status": "error", "message": "license_plate missing"}), 400

        exit_queue.put(data)  # Put data into the exit queue for processing

        print(f"[EXIT QUEUE SIZE]: {exit_queue.qsize()}")

        response = {
            "status": "received",
            "camera": "exit",
            "data": data
        }
        return jsonify(response), 200


def process_entry_data(app):
    while True:
        if not entry_queue.empty():
            data = entry_queue.get()
            with app.app_context():  # Establish application context here
                license_plate = data.get('license_plate')
                if license_plate:
                    # Call a function in your service layer to check for duplicates
                    if not is_duplicate_entry(license_plate):
                        print("[DEBUG] Processing entry data:", data)
                        handle_anpr_entry(data)
                    else:
                        print(f"[DEBUG] Duplicate entry detected for: {license_plate}")
                else:
                    print("[ERROR] License plate missing in entry data:", data)
        time.sleep(1)

def process_exit_data(app):
    while True:
        if not exit_queue.empty():
            data = exit_queue.get()
            with app.app_context():  # Establish application context here
                print("[DEBUG] Processing exit data:", data)
                handle_anpr_exit(data)
        time.sleep(1)

def start_camera_listeners(app):
    threading.Thread(target=process_entry_data, args=(app,), daemon=True).start()
    threading.Thread(target=process_exit_data, args=(app,), daemon=True).start()
