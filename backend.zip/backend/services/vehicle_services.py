from datetime import datetime
from models import db, Vehicle
import logging
import sys
from sqlalchemy import func  # Import the func module
from services.kiosk_services import generate_barcode, send_data_to_website  # Import the new function
from services.parking_slip_generator import generate_parking_slip_html # Import the function
from flask import current_app, jsonify
from services.on_exit_services import update_payment_status, exit_ping_on_exit
import requests
# KIOSK_ENDPOINT = "http://<kiosk_ip>:<port>/receive_entry"  # Replace with actual IP/port
# ✅ Define the target endpoint URL at the top (assuming local server)

EXIT_PING_ENDPOINT = "http://localhost:5000/exit_ping_on_exit"  # Replace with env/config if needed

logger = logging.getLogger(__name__)


def handle_anpr_entry(vehicle_data):
    """
    Handles ANPR entry data, checks for duplicates, creates a new vehicle entry,
    and sends data to a kiosk for barcode printing.

    Args:
        vehicle_data (dict): A dictionary containing vehicle information,
                            including 'license_plate' (required).
    """
    license_plate = vehicle_data.get("license_plate")

    if not license_plate:
        logger.error("License plate missing in entry data.")
        print("[ERROR] License plate missing in entry data.", file=sys.stderr)
        return

    # Check for duplicate active entry
    existing_vehicle = Vehicle.query.filter_by(license_plate=license_plate, status='in').first()
    if existing_vehicle:
        log_message = f"[INFO] Vehicle {license_plate} already inside."
        logger.info(log_message)
        print(log_message, file=sys.stdout)
        return

    now = datetime.utcnow()
    new_vehicle = Vehicle(
        license_plate=license_plate,
        entry_time=now,
        status='in'
    )
    db.session.add(new_vehicle)
    db.session.commit()

    log_message = f"[INFO] Entry recorded for vehicle: {new_vehicle}"
    logger.info(log_message)
    print(log_message, file=sys.stdout)

    # Generate barcode
    barcode_data = f"{license_plate}, {now.strftime('%Y-%m-%d %H:%M:%S')}"
    barcode_image_base64 = generate_barcode(barcode_data)  # Generate and get base64

    if not barcode_image_base64:
        logger.error(f"Failed to generate barcode for vehicle: {license_plate}")
        print(f"[ERROR] Failed to generate barcode for vehicle: {license_plate}", file=sys.stderr)
        #  IMPORTANT:  Consider if you want to block entry if barcode fails.  For now, continue.

    # Prepare data for HTML generation
    slip_data = {
        "vehicle_number": license_plate,
        "date": now.strftime('%Y-%m-%d'),
        "entry-time": now.strftime('%H:%M:%S'),
    }

    # Generate the HTML using the function from the new module
    html_content = generate_parking_slip_html(slip_data)


    # Payload to send to website
    website_payload = {
        "license_plate": license_plate,
        "entry_time": now.strftime('%Y-%m-%d %H:%M:%S'),
        "barcode_image": barcode_image_base64,
        "printable_slip": html_content, # pass the html content
    }
    send_data_to_website(website_payload)  # Send the data

def handle_anpr_exit(vehicle_data):
    """
    Handles ANPR exit: updates vehicle info, calculates duration/payment, 
    and returns response with full vehicle exit data.
    
    Args:
        vehicle_data (dict): Must contain 'license_plate'.
    
    Returns:
        (Flask Response): JSON response with vehicle exit info or error.
    """
    license_plate = vehicle_data.get("license_plate")
    if not license_plate:
        logger.error("License plate missing in exit data.")
        print("[ERROR] License plate missing in exit data.", file=sys.stderr)
        return jsonify({"status": "error", "message": "License plate missing"}), 400

    try:
        logger.debug(f"Searching for vehicle with plate: {license_plate}")

        vehicle = Vehicle.query.filter(
            func.lower(Vehicle.license_plate) == func.lower(license_plate),
            func.lower(Vehicle.status) == 'in'
        ).first()

        if not vehicle:
            logger.error(f"No active vehicle found with plate: {license_plate}")
            return jsonify({"status": "error", "message": "No active vehicle found inside"}), 404

        now = datetime.utcnow()
        duration = (now - vehicle.entry_time).total_seconds() / 60  # in minutes
        payable_amount = calculate_payment(duration)

        # Update vehicle details
        vehicle.exit_time = now
        vehicle.duration = now - vehicle.entry_time
        vehicle.payable_amount = payable_amount
        db.session.commit()

        # Prepare payload
        payload = {
            "status": "success",
            "message": "Vehicle data retrieved",
            "license_plate": vehicle.license_plate,
            "entry_time": vehicle.entry_time.isoformat() if vehicle.entry_time else None,
            "exit_time": vehicle.exit_time.isoformat() if vehicle.exit_time else None,
            "duration": duration if vehicle.duration else None,
            "payable_amount": round(vehicle.payable_amount, 2) if vehicle.payable_amount else None
        }

        # Optional: POST to external exit kiosk if needed
        try:
            response = requests.post(EXIT_PING_ENDPOINT, json=payload)
            response.raise_for_status()
            logger.info("Data sent to exit kiosk endpoint successfully.")
        except requests.RequestException as e:
            logger.warning(f"Failed to notify exit kiosk: {e}")

        # Allow exit only if payment is done
        if vehicle.payment_status != 'paid':
            logger.info(f"Payment not completed for vehicle: {license_plate}. Cannot exit.")
            return jsonify({"status": "unpaid", "message": "Payment not completed", **payload}), 403

        # Mark vehicle as out
        vehicle.status = 'out'
        db.session.commit()

        logger.info(f"Vehicle {license_plate} exited. Duration: {duration:.2f} mins, Payable: ₹{payable_amount:.2f}")
        return jsonify(payload), 200

    except Exception as e:
        logger.exception("Unexpected error during ANPR exit handling")
        return jsonify({"status": "error", "message": "Internal server error"}), 500
    
def calculate_payment(duration_minutes):
    """
    Calculates the parking fee based on the duration.  This is just an example;
    replace with your actual pricing logic.

    Args:
        duration_minutes (float): The parking duration in minutes.

    Returns:
        float: The amount due.
    """
    # Example logic: ₹10 for first 30 min, ₹1 per additional minute
    if duration_minutes <= 30:
        return 10.00
    else:
        return 10.00 + (duration_minutes - 30) * 1.00  # Ensure float multiplication


def is_duplicate_entry(license_plate):
    """
    Checks if there is an existing open entry for the given license plate.
    """
    open_entry = Vehicle.query.filter_by(license_plate=license_plate, status='in').first()
    return open_entry is not None