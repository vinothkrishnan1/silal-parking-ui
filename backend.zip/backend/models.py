from extensions import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash


class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # email = db.Column(db.String(120), unique=True, nullable=False)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(255), nullable=False)
    # is_temporary_password = db.Column(db.Boolean, default=True)  # check if the password is temporary
    role = db.Column(db.Enum('admin', 'user'), default='user', nullable=False)


    # Relationships
    verified_vehicles = db.relationship('Vehicle', backref='verifier', foreign_keys='Vehicle.verified_by', lazy=True)
    verified_waivers = db.relationship('WaivedUser', backref='verifier', foreign_keys='WaivedUser.verified_by', lazy=True)
    
    def __repr__(self):
        return f"<User {self.username}>"
    
    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password) 
    
    @classmethod
    def get_user_by_username(cls, username):
        return cls.query.filter_by(username = username).first()
    
    def save(self):
        db.session.add(self)
        db.session.commit()
    
    def delete(self):
        db.session.delete(self)
        db.session.commit()
    
        
    
class Vehicle(db.Model):
    __tablename__ = 'vehicles'
    
    id = db.Column(db.Integer, primary_key=True)
    license_plate = db.Column(db.String(20), unique=True, nullable=False)
    # vehicle_type = db.Column(db.String(50))
    
    # Audit fields
    entry_time = db.Column(db.DateTime, default=datetime.utcnow)
    exit_time = db.Column(db.DateTime)
    status = db.Column(db.Enum('in', 'out'), default='in')
    
    #duration
    duration = db.Column(db.Interval, nullable=True)
    
    # Payment fields
    payment_status = db.Column(db.Enum('paid', 'not paid', 'waived'), default='not paid')
    payment_mode = db.Column(db.Enum('cash', 'card'), default=None)
    payable_amount = db.Column(db.Float, default=None)
    
    # Verification info
    verified_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    verified_at = db.Column(db.DateTime, default=datetime.utcnow)
    image_path = db.Column(db.Text)
    
    

class WaivedUser(db.Model):
    __tablename__ = 'waived_users' 

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    waiver_id = db.Column(db.String(50), nullable=False)
    waiver_category = db.Column(db.String(100), nullable=False)
    reason = db.Column(db.String(255), nullable=False)
    
    # Verification info
    verified_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    verified_at = db.Column(db.DateTime, default=datetime.utcnow)
